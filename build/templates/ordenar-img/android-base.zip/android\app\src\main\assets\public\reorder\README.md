# Imágenes para el juego de Ordenamiento

Esta carpeta contiene las imágenes para los pasos de cada ejercicio del juego de ordenamiento.

## Estructura de carpetas

Cada ejercicio debe tener su propia carpeta con el ID del ejercicio, y dentro de ella, las imágenes para cada paso numeradas secuencialmente:

```
reorder/
├── b3/
│   ├── step-1.png
│   ├── step-2.png
│   ├── step-3.png
│   ├── step-4.png
│   └── step-5.png
├── b4/
│   ├── step-1.png
│   ├── step-2.png
│   ├── step-3.png
│   ├── step-4.png
│   └── step-5.png
└── b5/
    ├── step-1.png
    ├── step-2.png
    ├── step-3.png
    ├── step-4.png
    └── step-5.png
```

## Configuración de ejercicios

Los ejercicios se configuran en el archivo `/public/config/reorder-config.json`. Cada ejercicio debe tener:

- **id**: Identificador único del ejercicio (debe coincidir con el nombre de la carpeta)
- **title**: Título que se muestra en el juego
- **description**: Descripción del ejercicio
- **steps**: Array con los pasos en orden correcto

## Ejemplo de configuración

```json
{
  "ejercicios": [
    {
      "id": "b4",
      "title": "Uso de GPS",
      "description": "Cómo funciona el GPS.",
      "steps": [
        "Activar dispositivo",
        "Recibir señales",
        "Calcular posición",
        "Mostrar coordenadas",
        "Indicar ruta"
      ]
    }
  ]
}
```

Para este ejercicio, las imágenes deben estar en `/public/reorder/b4/step-1.png` hasta `/public/reorder/b4/step-5.png`.

## Nota importante

Si no se encuentran las imágenes en las rutas especificadas, pueden mostrarse imágenes rotas. Asegúrate de colocar todas las imágenes necesarias antes de ejecutar el juego.
