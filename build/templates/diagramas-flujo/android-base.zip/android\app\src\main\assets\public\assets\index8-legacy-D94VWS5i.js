System.register(["./index-legacy-CyeeIWv9.js"],function(o,e){"use strict";var t;return{setters:[o=>{t=o.a}],execute:function(){
/*!
             * (C) Ionic http://ionicframework.com - MIT License
             */
const e=o=>"ION-CONTENT"===o.tagName;o("g",async o=>e(o)?(await new Promise(e=>t(o,e)),o.getScrollElement()):o),o("f",o=>o.closest("ion-content, .ion-content-scroll-host")),o("s",(o,t)=>e(o)?o.scrollToTop(t):Promise.resolve(o.scrollTo({top:0,left:0,behavior:"smooth"}))),o("a",(o,t,s,r)=>e(o)?o.scrollByPoint(t,s,r):Promise.resolve(o.scrollBy({top:s,left:t,behavior:r>0?"smooth":"auto"})))}}});
